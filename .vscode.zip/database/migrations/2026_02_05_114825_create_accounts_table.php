<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->integer('shop_id');
            $table->date('date');
            $table->decimal('sell', 10, 2)->nullable();
            $table->decimal('market', 10, 2)->nullable();
            $table->decimal('visacard', 10, 2)->nullable();
            $table->decimal('snacks', 10, 2)->nullable();
            $table->decimal('drivar_bill', 10, 2)->nullable();
            $table->decimal('others', 10, 2)->nullable();
            $table->integer('created_by')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};
